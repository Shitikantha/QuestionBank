-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user_family_events`
--

DROP TABLE IF EXISTS `user_family_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_family_events` (
  `Family_Event_Id` bigint NOT NULL AUTO_INCREMENT,
  `User_Name` varchar(75) NOT NULL,
  `Relationship` varchar(45) NOT NULL,
  `First_Name` varchar(100) NOT NULL,
  `Last_Name` varchar(100) NOT NULL,
  `Events` json NOT NULL,
  `Is_Active` bit(1) DEFAULT NULL,
  `Created_Date` datetime NOT NULL,
  `Updated_Date` datetime DEFAULT NULL,
  `Is_Profile_Date` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Family_Event_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_family_events`
--

LOCK TABLES `user_family_events` WRITE;
/*!40000 ALTER TABLE `user_family_events` DISABLE KEYS */;
INSERT INTO `user_family_events` VALUES (1,'5','Children','Shannu','T','[{\"eventDate\": 1564963200000, \"eventName\": \"Birthday\"}]',_binary '','2021-11-29 02:58:18',NULL,_binary '\0'),(2,'KumaBand909952','Children','Kumari','Bandana','[{\"eventDate\": 1643241600000, \"eventName\": \"Birthday\"}]',_binary '','2021-12-28 06:43:04','2021-12-28 06:43:27',_binary '\0'),(3,'BandKuma680440','Children','Arjun','Choudhary','[{\"eventDate\": 1580083200000, \"eventName\": \"Birthday\"}]',_binary '','2021-12-29 11:45:21',NULL,_binary '\0'),(4,'BandKuma680440','Self','Kumari','Bandana','[{\"eventDate\": 621302400000, \"eventName\": \"Birthday\"}]',_binary '','2021-12-29 11:46:11',NULL,_binary '\0'),(5,'BandKuma680440','Spouse','Bikash','Choudhary','[{\"eventDate\": 616032000000, \"eventName\": \"Birthday\"}]',_binary '','2021-12-30 09:22:07',NULL,_binary '\0'),(6,'KumaBand909952','Father','Alakh kumar','Choudhary','[{\"eventDate\": 236476800000, \"eventName\": \"birthday\"}]',_binary '','2022-01-06 03:11:14',NULL,_binary '\0'),(7,'KumaBand909952','Children','Arjun','Choudhary','[{\"eventDate\": 1643414400000, \"eventName\": \"Bandana\"}]',_binary '','2022-01-13 07:57:43',NULL,_binary '\0'),(8,'KumaBand909952','Self','bandana','kumari','[{\"eventDate\": 621302400000, \"eventName\": \"birthday\"}]',_binary '','2022-01-13 09:23:56',NULL,_binary '\0'),(9,'MallEven158674','Self','MAlli','Test','[{\"eventDate\": 1644278400000, \"eventName\": \"Birthday\"}]',_binary '','2022-02-08 06:37:30','2022-04-06 10:50:23',_binary '\0'),(10,'NaveB342900','Children','Shannu','T','[{\"eventDate\": 1640995200000, \"eventName\": \"Birthday\"}]',_binary '','2022-02-16 13:19:48',NULL,_binary '\0'),(11,'NaveB342900','Brother','Mahesh','T','[{\"eventDate\": 1638748800000, \"eventName\": \"New Houser Purchage\"}]',_binary '','2022-02-16 13:20:56',NULL,_binary '\0'),(14,'MohaAzma588006','Father','ABC','Az','[{\"eventDate\": 1648598400000, \"eventName\": \"Birthday\"}]',_binary '','2022-03-21 09:38:20',NULL,_binary '\0'),(15,'Rajeg934445','Self','Mallikarjuna','T','[{\"eventDate\": 1644796800000, \"eventName\": \"Birthday\"}]',_binary '','2022-03-22 03:10:47','2022-03-22 09:04:07',_binary '\0'),(16,'testEmp999957','Friends','Amit','H','[{\"eventDate\": 1648598400000, \"eventName\": \"Anniversary\"}]',_binary '','2022-03-22 07:44:14',NULL,_binary '\0'),(17,'Rajeg934445','Spouse','Charith','T','[{\"eventDate\": 1653782400000, \"eventName\": \"Anniversary\"}]',_binary '','2022-03-22 09:05:55',NULL,_binary '\0'),(19,'testEmp999957','Friends','Aakash','Dalawai','[{\"eventDate\": 1675641600000, \"eventName\": \"Anniversary\"}]',_binary '','2022-03-29 09:00:58',NULL,_binary '\0'),(20,'VijaServ869995','Self','Test Birthday','V','[{\"eventDate\": 1650844800000, \"eventName\": \"Birthday\"}, {\"eventDate\": 1650931200000, \"eventName\": \"Anniversary\"}]',_binary '','2022-04-04 14:10:59','2022-04-04 14:11:15',_binary '\0'),(21,'VijaServ869995','Self','Vijay','Serv','[{\"eventDate\": 1649030400000, \"eventName\": \"Birthday\"}]',_binary '','2022-04-04 14:11:46','2022-04-04 14:16:01',_binary ''),(22,'VijaServ869995','Self','Vijay','Serv','[{\"eventDate\": 1650326400000, \"eventName\": \"Anniversary\"}]',_binary '','2022-04-04 14:11:46','2022-04-04 14:16:01',_binary ''),(23,'onebbpm780363','Self','onebpmtest','bpm','[{\"eventDate\": 1666396800000, \"eventName\": \"Birthday\"}]',_binary '','2022-04-05 06:24:40','2022-06-03 15:48:10',_binary ''),(24,'onebbpm780363','Self','onebpmtest','bpm','[{\"eventDate\": 1656460800000, \"eventName\": \"Anniversary\"}]',_binary '','2022-04-05 06:24:40','2022-06-03 15:51:23',_binary ''),(25,'onebbpm780363','Self','balu','P','[{\"eventDate\": 1656547200000, \"eventName\": \"test\"}]',_binary '','2022-04-05 06:28:18','2022-06-03 15:50:26',_binary '\0'),(27,'BidyBara217511','Self','Bidyut','Baral','[{\"eventDate\": 836956800000, \"eventName\": \"Birthday\"}]',_binary '','2022-04-06 10:28:54','2022-04-06 10:30:06',_binary ''),(28,'BidyBara217511','Father','Dhirendra','Baral','[{\"eventDate\": 806630400000, \"eventName\": \"Anniversary\"}]',_binary '','2022-04-06 10:29:51',NULL,_binary '\0'),(29,'MallEven158674','Spouse','Shannu','t','[{\"eventDate\": 1653782400000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-10 10:04:41',NULL,_binary '\0'),(30,'MallEven158674','Mother','Vajravthi','Thodeti','[{\"eventDate\": 1653436800000, \"eventName\": \"Vajravathi\"}, {\"eventDate\": 1654128000000, \"eventName\": \"Anniversary\"}, {\"eventDate\": 1653264000000, \"eventName\": \"Sons Birthday\"}]',_binary '','2022-05-13 06:50:29',NULL,_binary '\0'),(31,'MallEven158674','Children','Manu','T','[{\"eventDate\": 1664755200000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-13 10:22:06',NULL,_binary '\0'),(32,'MallEven158674','Wife','Uma','T','[{\"eventDate\": 1660089600000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-13 10:22:33',NULL,_binary '\0'),(33,'MallEven158674','sister','Kalpana','T','[{\"eventDate\": 1663286400000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-13 10:23:07',NULL,_binary '\0'),(34,'MallEven158674','Spouse','Cherry','B','[{\"eventDate\": 1663027200000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-13 10:23:30',NULL,_binary '\0'),(35,'MallEven158674','Father','Venkki','T','[{\"eventDate\": 1658966400000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-17 09:04:06',NULL,_binary '\0'),(36,'MallEven158674','Father','Venkateswarlu','y','[{\"eventDate\": 1653955200000, \"eventName\": \"Anniversary\"}]',_binary '','2022-05-17 10:48:39','2022-05-17 10:49:50',_binary '\0'),(37,'MallEven158674','Mother','mom','n','[{\"eventDate\": 1653436800000, \"eventName\": \"Wassss\"}]',_binary '','2022-05-17 10:51:00',NULL,_binary '\0'),(38,'MallEven158674','Children','May','May','[{\"eventDate\": 1653177600000, \"eventName\": \"Twenty Two\"}]',_binary '','2022-05-17 10:52:10',NULL,_binary '\0'),(39,'MallEven158674','Children','Shannu','T','[{\"eventDate\": 1654214400000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-31 09:04:47',NULL,_binary '\0'),(40,'MallEven158674','Self','MAlli','t','[{\"eventDate\": 1654473600000, \"eventName\": \"Birthday\"}]',_binary '','2022-05-31 11:21:50',NULL,_binary '\0'),(41,'onebbpm780363','Self','mohankumar','B','[{\"eventDate\": 1654473600000, \"eventName\": \"Daughter birthday\"}]',_binary '','2022-06-01 06:41:54',NULL,_binary '\0'),(42,'MallEven158674','Father','Venkat','T','[{\"eventDate\": 1654732800000, \"eventName\": \"Anniversary\"}]',_binary '','2022-06-01 07:09:30',NULL,_binary '\0'),(43,'onebbpm780363','Self','Thamarai','Selevan','[{\"eventDate\": 1655510400000, \"eventName\": \"birthday\"}]',_binary '','2022-06-01 07:19:43','2022-06-01 07:21:35',_binary '\0'),(44,'onebbpm780363','Self','est','yyy','[{\"eventDate\": 1750032000000, \"eventName\": \"esttt\"}]',_binary '','2022-06-01 07:22:07','2022-06-03 15:52:22',_binary '\0'),(45,'onebbpm780363','Self','selll','lllll','[{\"eventDate\": 1657152000000, \"eventName\": \"llll\"}]',_binary '','2022-06-03 15:51:50',NULL,_binary '\0'),(46,'Manvt676071','Children','Manvuka','Thodeti','[{\"eventDate\": 1664755200000, \"eventName\": \"Birthday\"}]',_binary '','2022-06-06 06:19:34',NULL,_binary '\0'),(47,'Manvt676071','Self','Shanvika','Thodeti','[{\"eventDate\": 1659657600000, \"eventName\": \"Birthday\"}]',_binary '','2022-06-06 06:49:31',NULL,_binary '\0'),(48,'Manvt676071','Self','Test','Aee','[{\"eventDate\": 1656547200000, \"eventName\": \"Test\"}]',_binary '','2022-06-06 07:02:40',NULL,_binary '\0'),(49,'Manvt676071','Children','Nnnn','ggt','[{\"eventDate\": 1655856000000, \"eventName\": \"Ettt\"}]',_binary '','2022-06-06 07:04:37',NULL,_binary '\0'),(50,'Manvt676071','Father','rrr','rrrr','[{\"eventDate\": 1656460800000, \"eventName\": \"Rrrr\"}]',_binary '','2022-06-06 07:05:20',NULL,_binary '\0'),(51,'MallEven158674','Children','Shannu','T','[{\"eventDate\": 1689724800000, \"eventName\": \"Birthday\"}]',_binary '','2023-05-29 05:46:37',NULL,_binary '\0'),(52,'Anankris325060','Self','Anantha','krish','[{\"eventDate\": 1686355200000, \"eventName\": \"Birthday\"}]',_binary '','2023-06-12 05:25:15',NULL,_binary ''),(53,'vignP395173','Self','vignesh','P','[{\"eventDate\": 839548800000, \"eventName\": \"Birthday\"}]',_binary '','2023-06-13 05:18:01','2023-06-15 07:55:48',_binary '');
/*!40000 ALTER TABLE `user_family_events` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:32:13
