-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `renewal_sp_business_owner_info`
--

DROP TABLE IF EXISTS `renewal_sp_business_owner_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `renewal_sp_business_owner_info` (
  `Renewal_Id` bigint NOT NULL AUTO_INCREMENT,
  `SP_Reg_Id` bigint NOT NULL,
  `Service_Provider_Id` varchar(75) NOT NULL,
  `Business_Metadata` json DEFAULT NULL,
  `Registration_Status` varchar(50) DEFAULT NULL,
  `Created_Date` datetime DEFAULT NULL,
  `Updated_Date` datetime DEFAULT NULL,
  `Is_Active` bit(1) DEFAULT NULL,
  `Send_For_Approval_Date` datetime DEFAULT NULL,
  `Business_Status_Metadata` json DEFAULT NULL,
  PRIMARY KEY (`Renewal_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `renewal_sp_business_owner_info`
--

LOCK TABLES `renewal_sp_business_owner_info` WRITE;
/*!40000 ALTER TABLE `renewal_sp_business_owner_info` DISABLE KEYS */;
INSERT INTO `renewal_sp_business_owner_info` VALUES (11,167,'Rakeserv186196','{\"ssnNo\": \"cCxfYk7yQqV6RPtVW9mMRg==\", \"emailId\": \"SOlFVcec8PHCFJHbmvgp7uUGYxF63SugiTI77AacRGg=\", \"vendorName\": \"Rakesh A-Z Business\", \"contactNumber\": \"0eBiKB6L+cTzvcyvIioMgg==\", \"languagesKnown\": null, \"emergencyContact\": \"lbK3+x6L16cFX6znXgCxNA==\"}','REJECTED','2022-09-02 12:00:50','2022-10-28 10:37:18',_binary '','2022-10-27 11:20:11','[{\"status\": \"REJECTED\", \"reviewDate\": 1666953438081, \"adminComment\": \"dddd\", \"submittedDate\": 1666869610681, \"vendorComment\": null}]'),(12,164,'HarsServ540941','{\"ssnNo\": \"VSu7KXru0BBtYc3CDFRIig==\", \"emailId\": \"t+Zjf2fQulPu/yYhpXyqKdhCi4hQbi41AtNro4x6HvY=\", \"vendorName\": \"Illiana Robertson\", \"contactNumber\": \"mEM49atJbYauWpt+FR0h4g==\", \"languagesKnown\": null, \"emergencyContact\": \"IiQGRMvuZ/Peo3bVZJ5LMA==\"}','APPROVED','2022-09-05 04:57:02','2022-09-05 05:11:08',_binary '\0','2022-09-05 05:01:09',NULL),(13,164,'HarsServ540941','{\"ssnNo\": \"VSu7KXru0BBtYc3CDFRIig==\", \"emailId\": \"t+Zjf2fQulPu/yYhpXyqKdhCi4hQbi41AtNro4x6HvY=\", \"vendorName\": \"Illiana Robertson\", \"contactNumber\": \"mEM49atJbYauWpt+FR0h4g==\", \"languagesKnown\": null, \"emergencyContact\": \"IiQGRMvuZ/Peo3bVZJ5LMA==\"}','APPROVED','2022-09-05 05:12:00','2022-09-05 05:20:36',_binary '\0','2022-09-05 05:20:08',NULL),(14,164,'HarsServ540941','{\"ssnNo\": \"VSu7KXru0BBtYc3CDFRIig==\", \"emailId\": \"t+Zjf2fQulPu/yYhpXyqKdhCi4hQbi41AtNro4x6HvY=\", \"vendorName\": \"Illiana Robertson\", \"contactNumber\": \"mEM49atJbYauWpt+FR0h4g==\", \"languagesKnown\": null, \"emergencyContact\": \"eZbdAdMT9waWD/mpktyMtA==\"}','APPROVED','2022-09-05 05:21:56','2022-09-05 05:36:17',_binary '\0','2022-09-05 05:32:21',NULL),(15,164,'HarsServ540941','{\"ssnNo\": \"VSu7KXru0BBtYc3CDFRIig==\", \"emailId\": \"t+Zjf2fQulPu/yYhpXyqKdhCi4hQbi41AtNro4x6HvY=\", \"vendorName\": \"Illiana Robertson\", \"contactNumber\": \"mEM49atJbYauWpt+FR0h4g==\", \"languagesKnown\": null, \"emergencyContact\": \"dyrUBqaoSUw0fKj2FMparw==\"}','APPROVED','2022-09-05 05:39:08','2022-09-05 05:41:09',_binary '\0','2022-09-05 05:40:27',NULL),(16,164,'HarsServ540941','{\"ssnNo\": \"VSu7KXru0BBtYc3CDFRIig==\", \"emailId\": \"t+Zjf2fQulPu/yYhpXyqKdhCi4hQbi41AtNro4x6HvY=\", \"vendorName\": \"Illiana Robertson\", \"contactNumber\": \"mEM49atJbYauWpt+FR0h4g==\", \"languagesKnown\": null, \"emergencyContact\": \"dyrUBqaoSUw0fKj2FMparw==\"}','APPROVED','2022-09-05 05:43:32','2022-09-05 06:16:02',_binary '\0','2022-09-05 05:44:26',NULL),(17,164,'HarsServ540941','{\"ssnNo\": \"VSu7KXru0BBtYc3CDFRIig==\", \"emailId\": \"t+Zjf2fQulPu/yYhpXyqKdhCi4hQbi41AtNro4x6HvY=\", \"vendorName\": \"Illiana Robertson\", \"contactNumber\": \"mEM49atJbYauWpt+FR0h4g==\", \"languagesKnown\": null, \"emergencyContact\": \"ITkn7hg/g+TYZPRDCGpxrQ==\"}','APPROVED','2022-09-05 06:17:25','2022-09-05 06:28:55',_binary '\0','2022-09-05 06:28:35',NULL),(18,163,'MallServ386183','{\"ssnNo\": \"QRV4mUly6TscSdHxGDnEdQ==\", \"emailId\": \"VDP5JsMv1ww/gAhTwWkX5VI7zgzMG6g8SLSfyylH548=\", \"vendorName\": \"Gemma Gibson\", \"contactNumber\": \"WzKjv5OKKDsJkGbm5XLy0A==\", \"languagesKnown\": null, \"emergencyContact\": \"leAJmbTm1MaiOu6o/H1Mig==\"}','APPROVED','2022-09-05 06:49:00','2022-09-07 07:41:58',_binary '\0','2022-09-05 06:50:07',NULL),(19,169,'RajeG925250','{\"ssnNo\": \"y+N7ypaFyOdn84XY2FnP5Q==\", \"emailId\": \"VDP5JsMv1ww/gAhTwWkX5VI7zgzMG6g8SLSfyylH548=\", \"vendorName\": \"Mahesh\", \"contactNumber\": \"dyrUBqaoSUw0fKj2FMparw==\", \"languagesKnown\": null, \"emergencyContact\": \"mEM49atJbYauWpt+FR0h4g==\"}',NULL,'2022-09-05 09:44:30',NULL,_binary '',NULL,NULL),(20,165,'threbpm232264','{\"ssnNo\": \"VFbD5CgmwcIEa3VhnwOdeg==\", \"emailId\": \"EhZjK2YntlBKyOEYHwemJuJ3tl/bn+ksoVvyGSfEwNM=\", \"vendorName\": \"Mohan Services\", \"contactNumber\": \"WEJwMqkEd4TNDn+WQWld2g==\", \"languagesKnown\": null, \"emergencyContact\": \"WEJwMqkEd4TNDn+WQWld2g==\"}','APPROVED','2022-09-05 11:14:06','2022-09-06 05:23:56',_binary '\0','2022-09-05 11:17:12',NULL),(22,179,'hariP208511','{\"ssnNo\": \"c2Mzy+P3Ph+5dnmMaHlFtg==\", \"emailId\": \"phnHOm2lTiz1iTvAUBpzNeJ3tl/bn+ksoVvyGSfEwNM=\", \"vendorName\": \"Mohankumar\", \"contactNumber\": \"O/AVMx3pW7ti/2EoCbB1cQ==\", \"languagesKnown\": null, \"emergencyContact\": \"O/AVMx3pW7ti/2EoCbB1cQ==\"}',NULL,'2022-09-06 05:28:57','2022-09-07 07:50:34',_binary '',NULL,NULL),(23,163,'MallServ386183','{\"ssnNo\": \"QRV4mUly6TscSdHxGDnEdQ==\", \"emailId\": \"VDP5JsMv1ww/gAhTwWkX5VI7zgzMG6g8SLSfyylH548=\", \"vendorName\": \"Gemma Gibson\", \"contactNumber\": \"WzKjv5OKKDsJkGbm5XLy0A==\", \"languagesKnown\": null, \"emergencyContact\": \"leAJmbTm1MaiOu6o/H1Mig==\"}','APPROVED','2022-09-07 07:44:31','2022-09-07 09:14:30',_binary '\0','2022-09-07 08:22:52',NULL),(24,164,'HarsServ540941','{\"ssnNo\": \"VSu7KXru0BBtYc3CDFRIig==\", \"emailId\": \"t+Zjf2fQulPu/yYhpXyqKdhCi4hQbi41AtNro4x6HvY=\", \"vendorName\": \"Illiana Robertson\", \"contactNumber\": \"mEM49atJbYauWpt+FR0h4g==\", \"languagesKnown\": null, \"emergencyContact\": \"ITkn7hg/g+TYZPRDCGpxrQ==\"}',NULL,'2022-09-07 10:28:09','2022-09-07 10:33:32',_binary '',NULL,NULL),(25,180,'MuraKris249355','{\"ssnNo\": \"SaPgwIzhNQpSthoTM9O63w==\", \"emailId\": \"P2N+ppebdRwGHhV9Ibp2oVF5EegkKm1PA/goQugZrHA=\", \"vendorName\": \"Murali\", \"contactNumber\": \"dyrUBqaoSUw0fKj2FMparw==\", \"languagesKnown\": null, \"emergencyContact\": \"mEM49atJbYauWpt+FR0h4g==\"}','APPROVED','2022-09-08 09:52:22','2022-09-08 10:43:27',_binary '\0','2022-09-08 10:03:03',NULL),(26,180,'MuraKris249355','{\"ssnNo\": \"SaPgwIzhNQpSthoTM9O63w==\", \"emailId\": \"P2N+ppebdRwGHhV9Ibp2oVF5EegkKm1PA/goQugZrHA=\", \"vendorName\": \"Murali\", \"contactNumber\": \"dyrUBqaoSUw0fKj2FMparw==\", \"languagesKnown\": null, \"emergencyContact\": \"mEM49atJbYauWpt+FR0h4g==\"}','APPROVED','2022-09-08 10:44:27','2023-05-05 07:18:58',_binary '\0','2023-04-20 08:18:35','[{\"status\": \"APPROVED\", \"reviewDate\": 1683271138316, \"adminComment\": \"Verified & Approved\", \"submittedDate\": 1681978715457, \"vendorComment\": null}]'),(27,181,'ZaheSH858872','{\"ssnNo\": \"r6fKVepJmyRTtp4yCL3Bhw==\", \"emailId\": \"9XwHPOXx/wGuCQ/YJFUth26rmhOK32FWic5vuPW76tw=\", \"vendorName\": \"Zaheer\", \"contactNumber\": \"dyrUBqaoSUw0fKj2FMparw==\", \"languagesKnown\": null, \"emergencyContact\": \"mEM49atJbYauWpt+FR0h4g==\"}','APPROVED','2022-09-08 10:55:37','2022-09-08 11:01:25',_binary '\0','2022-09-08 11:00:58',NULL),(28,181,'ZaheSH858872','{\"ssnNo\": \"r6fKVepJmyRTtp4yCL3Bhw==\", \"emailId\": \"9XwHPOXx/wGuCQ/YJFUth26rmhOK32FWic5vuPW76tw=\", \"vendorName\": \"Zaheer\", \"contactNumber\": \"dyrUBqaoSUw0fKj2FMparw==\", \"languagesKnown\": null, \"emergencyContact\": \"mEM49atJbYauWpt+FR0h4g==\"}',NULL,'2022-09-08 11:08:35',NULL,_binary '',NULL,NULL),(29,163,'MallServ386183','{\"ssnNo\": \"QRV4mUly6TscSdHxGDnEdQ==\", \"emailId\": \"VDP5JsMv1ww/gAhTwWkX5VI7zgzMG6g8SLSfyylH548=\", \"vendorName\": \"Gemma Gibson\", \"contactNumber\": \"WzKjv5OKKDsJkGbm5XLy0A==\", \"languagesKnown\": null, \"emergencyContact\": \"leAJmbTm1MaiOu6o/H1Mig==\"}','REJECTED','2022-09-09 14:39:21','2022-10-28 10:31:46',_binary '','2022-10-28 10:31:14','[{\"status\": \"REJECTED\", \"reviewDate\": 1666952890499, \"adminComment\": \"Need some more details\", \"submittedDate\": 1666952771025, \"vendorComment\": null}, {\"status\": \"REJECTED\", \"reviewDate\": 1666953106430, \"adminComment\": \"same problem\", \"submittedDate\": 1666953074254, \"vendorComment\": \"add details\"}]'),(30,165,'threbpm232264','{\"ssnNo\": \"VFbD5CgmwcIEa3VhnwOdeg==\", \"emailId\": \"EhZjK2YntlBKyOEYHwemJuJ3tl/bn+ksoVvyGSfEwNM=\", \"vendorName\": \"Mohan Services\", \"contactNumber\": \"WEJwMqkEd4TNDn+WQWld2g==\", \"languagesKnown\": null, \"emergencyContact\": \"WEJwMqkEd4TNDn+WQWld2g==\"}','APPROVED','2022-10-10 09:17:05','2022-10-10 09:26:30',_binary '\0','2022-10-10 09:17:50',NULL),(31,180,'MuraKris249355','{\"ssnNo\": \"SaPgwIzhNQpSthoTM9O63w==\", \"emailId\": \"P2N+ppebdRwGHhV9Ibp2oVF5EegkKm1PA/goQugZrHA=\", \"vendorName\": \"Murali\", \"contactNumber\": \"dyrUBqaoSUw0fKj2FMparw==\", \"languagesKnown\": null, \"emergencyContact\": \"mEM49atJbYauWpt+FR0h4g==\"}','PENDING ADMIN APPROVAL','2023-05-05 07:19:34',NULL,_binary '','2023-05-05 07:20:45','[{\"status\": \"PENDING ADMIN APPROVAL\", \"reviewDate\": null, \"adminComment\": null, \"submittedDate\": 1683271244705, \"vendorComment\": null}]'),(36,204,'vignp170329','{\"ssnNo\": null, \"emailId\": \"USCsOcyBKyiq3mA4J+hMigsrTnO4rGqi/MBBkwL/pTg=\", \"vendorName\": \"vignesh p\", \"contactNumber\": \"rfnVKbLZ6pmef8yLiL63TA==\", \"languagesKnown\": null, \"emergencyContact\": null}',NULL,'2023-06-14 05:36:11',NULL,_binary '',NULL,NULL);
/*!40000 ALTER TABLE `renewal_sp_business_owner_info` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:32:19
