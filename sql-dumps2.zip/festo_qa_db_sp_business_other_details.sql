-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `sp_business_other_details`
--

DROP TABLE IF EXISTS `sp_business_other_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sp_business_other_details` (
  `Other_Details_Id` bigint NOT NULL AUTO_INCREMENT,
  `Sp_Reg_Id` bigint DEFAULT NULL,
  `Business_Metadata` json DEFAULT NULL,
  `Created_Date` datetime DEFAULT NULL,
  `Updated_Date` datetime DEFAULT NULL,
  `Is_Active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Other_Details_Id`),
  KEY `Sp_Reg_Id` (`Sp_Reg_Id`),
  CONSTRAINT `sp_business_other_details_ibfk_1` FOREIGN KEY (`Sp_Reg_Id`) REFERENCES `sp_business_owner_info` (`SP_Reg_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sp_business_other_details`
--

LOCK TABLES `sp_business_other_details` WRITE;
/*!40000 ALTER TABLE `sp_business_other_details` DISABLE KEYS */;
INSERT INTO `sp_business_other_details` VALUES (162,162,'{\"awards\": [{\"awardTitle\": \"People choice\", \"awardedDate\": 1641168000000, \"description\": \"Testserv\"}, {\"awardTitle\": \"Award choice\", \"awardedDate\": 1641168000000, \"description\": \"Choices\"}]}','2022-01-03 10:46:12','2022-01-03 10:47:03',_binary ''),(163,163,'{\"awards\": [{\"awardTitle\": \"AWS\", \"awardedDate\": 1641168000000, \"description\": \"West\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-07 07:44:31','2022-09-07 09:14:30',_binary ''),(164,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}, {\"awardTitle\": \"Renuwal\", \"awardedDate\": 1661990400000, \"description\": \"Se\"}]}','2022-09-05 06:17:25','2022-09-05 06:28:55',_binary ''),(165,165,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-10-10 09:17:06','2022-10-10 09:26:30',_binary ''),(166,167,'{\"awards\": [{\"awardTitle\": \"sfdf\", \"awardedDate\": 1641772800000, \"description\": \"sfdf\"}, {\"awardTitle\": \"dfdf\", \"awardedDate\": 1641772800000, \"description\": \"sdfd\"}]}','2022-01-10 10:37:24',NULL,_binary ''),(167,168,'{\"awards\": [{\"awardTitle\": \"Totam sint ipsum enim dolor quia eum exercitation\", \"awardedDate\": 92880000000, \"description\": \"Suscipit in fugit culpa ex voluptate nemo culpa aute in natus sit\"}, {\"awardTitle\": \"Voluptatem maxime aut in quos reprehenderit excep\", \"awardedDate\": 915148800000, \"description\": \"Sed ipsam nisi velit totam odit magna\"}]}','2022-01-20 08:58:13','2023-06-12 06:35:21',_binary ''),(168,169,'{\"awards\": [{\"awardTitle\": \"Best services 2021\", \"awardedDate\": 1640995200000, \"description\": \"Best services\"}, {\"awardTitle\": \"Nellore Best\", \"awardedDate\": 1642118400000, \"description\": \"Best\"}]}','2022-01-28 05:56:21',NULL,_binary ''),(169,170,'{\"awards\": [{\"awardTitle\": \"Unde soluta sit et veritatis laboris eos in fugi\", \"awardedDate\": 439344000000, \"description\": \"Sit modi voluptatem quos fugiat neque ut beatae ullam laborum Modi illum nostrud asperiores qui\"}, {\"awardTitle\": \"Facilis sequi quis quidem qui omnis sed repellendu\", \"awardedDate\": 701913600000, \"description\": \"Harum beatae placeat est est necessitatibus nisi et tempora omnis sequi\"}]}','2022-02-01 06:16:45',NULL,_binary ''),(170,171,'{\"awards\": [{\"awardTitle\": \"Certificate R & R\", \"awardedDate\": 1643846400000, \"description\": \"R & R\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-02-03 10:11:07',NULL,_binary ''),(171,166,'{\"awards\": [{\"awardTitle\": \"Best service in 2020\", \"awardedDate\": 1643673600000, \"description\": \"Best services\"}, {\"awardTitle\": \"New Services\", \"awardedDate\": 1643673600000, \"description\": \"All services\"}]}','2022-02-07 09:43:58','2022-02-07 09:44:16',_binary ''),(172,173,'{\"awards\": [{\"awardTitle\": \"Aliquid adipisicing est lorem minima quisquam sap\", \"awardedDate\": 1474070400000, \"description\": \"Est suscipit ab cupidatat nostrum commodi\"}, {\"awardTitle\": \"Voluptatibus optio amet accusantium lorem\", \"awardedDate\": 966470400000, \"description\": \"Quae deserunt dolor dolore consequuntur sint odit quod aut vel sint architecto unde quos aut amet \"}]}','2022-02-10 04:50:23',NULL,_binary ''),(173,172,'{\"awards\": [{\"awardTitle\": \"AWS\", \"awardedDate\": 1640995200000, \"description\": \"Best service 2020\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-02-11 03:25:39',NULL,_binary ''),(174,174,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-02-16 12:07:53',NULL,_binary ''),(175,175,'{\"awards\": [{\"awardTitle\": \"kkkkjdkj\", \"awardedDate\": 1644796800000, \"description\": \"jhjjhjh\"}, {\"awardTitle\": \"kkjkjkj\", \"awardedDate\": 1644796800000, \"description\": \"jkjjkkj\"}]}','2022-02-17 14:08:29',NULL,_binary ''),(176,177,'{\"awards\": [{\"awardTitle\": \"Sit quaerat officia nobis quo labore modi molestia\", \"awardedDate\": 678844800000, \"description\": \"Sequi duis consequatur Consequatur culpa ut ipsa placeat in id non assumenda dignissimos omnis si\"}, {\"awardTitle\": \"Est culpa cumque eum id ullam commodi veritatis \", \"awardedDate\": 3628800000, \"description\": \"Non iure maxime cupiditate adipisicing\"}]}','2022-02-21 07:41:35',NULL,_binary ''),(177,178,'{\"awards\": [{\"awardTitle\": \"Excepturi adipisicing et eum ullam alias quis ipsa\", \"awardedDate\": 1267315200000, \"description\": \"Vero velit tenetur quis dicta quia dicta et itaque ea ipsum facilis in\"}, {\"awardTitle\": \"Ratione quam est dolores ut voluptate quia ad sin\", \"awardedDate\": 1175990400000, \"description\": \"Maiores officiis dignissimos ipsum sed odit delectus fuga Temporibus esse et\"}]}','2022-02-21 08:32:19',NULL,_binary ''),(178,176,'{\"awards\": [{\"awardTitle\": \"Best services in 2021\", \"awardedDate\": 1640995200000, \"description\": \"Latest\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-02-21 08:51:59',NULL,_binary ''),(179,179,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-02-21 17:06:57','2022-02-21 17:16:11',_binary ''),(180,180,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-08 10:44:27','2023-05-05 07:18:58',_binary ''),(181,181,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-08 10:55:37','2022-09-08 11:01:25',_binary ''),(182,182,'{\"awards\": [{\"awardTitle\": \"test1\", \"awardedDate\": 971136000000, \"description\": \"test\"}, {\"awardTitle\": \"test2\", \"awardedDate\": 1648771200000, \"description\": \"test\"}]}','2022-04-19 10:14:28','2022-04-19 10:37:56',_binary ''),(183,183,'{\"awards\": [{\"awardTitle\": \"Testrr\", \"awardedDate\": 1648771200000, \"description\": \"Hyderbad\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-04-20 05:49:42','2022-04-20 05:54:18',_binary ''),(184,184,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-04-21 10:06:26','2022-04-21 10:07:35',_binary ''),(189,187,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-04-22 11:13:01',NULL,_binary ''),(190,188,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-04-28 07:39:50',NULL,_binary ''),(191,189,'{\"awards\": [{\"awardTitle\": \"aa\", \"awardedDate\": 1655251200000, \"description\": \"aa\"}, {\"awardTitle\": \"dsds\", \"awardedDate\": 1655078400000, \"description\": \"aa\"}]}','2022-06-17 06:41:24',NULL,_binary ''),(192,190,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-06-21 09:07:13',NULL,_binary ''),(193,192,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-06-23 10:51:57','2022-06-23 10:52:37',_binary ''),(194,193,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-06-24 10:37:38','2022-06-24 10:38:39',_binary ''),(195,194,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1656633600000, \"description\": \"Test\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-07-06 08:44:49',NULL,_binary ''),(196,195,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-07-21 06:23:14','2022-07-21 06:27:01',_binary ''),(197,196,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-08-08 04:19:18','2022-08-08 04:47:21',_binary ''),(198,197,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-08-09 05:05:31','2022-09-05 10:08:47',_binary ''),(199,198,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-08-26 06:58:21','2022-08-26 06:59:42',_binary ''),(200,199,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-08-26 09:48:46',NULL,_binary ''),(201,200,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-14 04:55:11',NULL,_binary ''),(202,201,'{\"awards\": [{\"awardTitle\": \"Amzon\", \"awardedDate\": 1661990400000, \"description\": \"Apps\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-14 09:55:18',NULL,_binary ''),(203,202,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2023-03-10 06:54:29',NULL,_binary ''),(204,204,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2023-06-12 07:18:29',NULL,_binary '');
/*!40000 ALTER TABLE `sp_business_other_details` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:30:05
