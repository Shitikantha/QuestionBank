-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `renewal_sp_business_other_details`
--

DROP TABLE IF EXISTS `renewal_sp_business_other_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `renewal_sp_business_other_details` (
  `Renewal_Other_Details_Id` bigint NOT NULL AUTO_INCREMENT,
  `Renewal_Id` bigint NOT NULL,
  `Sp_Reg_Id` bigint NOT NULL,
  `Business_Metadata` json DEFAULT NULL,
  `Created_Date` datetime DEFAULT NULL,
  `Updated_Date` datetime DEFAULT NULL,
  `Is_Active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`Renewal_Other_Details_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `renewal_sp_business_other_details`
--

LOCK TABLES `renewal_sp_business_other_details` WRITE;
/*!40000 ALTER TABLE `renewal_sp_business_other_details` DISABLE KEYS */;
INSERT INTO `renewal_sp_business_other_details` VALUES (7,11,167,'{\"awards\": [{\"awardTitle\": \"sfdf\", \"awardedDate\": 1641772800000, \"description\": \"sfdf\"}, {\"awardTitle\": \"dfdf\", \"awardedDate\": 1641772800000, \"description\": \"sdfd\"}]}','2022-09-02 12:00:50','2022-09-02 12:02:20',_binary ''),(8,12,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}]}','2022-09-05 04:57:02','2022-09-05 05:01:01',_binary ''),(9,13,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}, {\"awardTitle\": \"Renuwal\", \"awardedDate\": 1661990400000, \"description\": \"Se\"}]}','2022-09-05 05:12:00','2022-09-05 05:20:03',_binary ''),(10,14,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}, {\"awardTitle\": \"Renuwal\", \"awardedDate\": 1661990400000, \"description\": \"Se\"}]}','2022-09-05 05:21:56','2022-09-05 05:23:29',_binary ''),(11,15,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}, {\"awardTitle\": \"Renuwal\", \"awardedDate\": 1661990400000, \"description\": \"Se\"}]}','2022-09-05 05:39:08','2022-09-05 05:40:21',_binary ''),(12,16,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}, {\"awardTitle\": \"Renuwal\", \"awardedDate\": 1661990400000, \"description\": \"Se\"}]}','2022-09-05 05:43:32','2022-09-05 05:44:03',_binary ''),(13,17,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}, {\"awardTitle\": \"Renuwal\", \"awardedDate\": 1661990400000, \"description\": \"Se\"}]}','2022-09-05 06:17:25','2022-09-05 06:28:30',_binary ''),(14,18,163,'{\"awards\": [{\"awardTitle\": \"AWS\", \"awardedDate\": 1641168000000, \"description\": \"West\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-05 06:49:00','2022-09-05 06:49:41',_binary ''),(15,19,169,'{\"awards\": [{\"awardTitle\": \"Best services 2021\", \"awardedDate\": 1640995200000, \"description\": \"Best services\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-05 09:44:30','2022-09-05 09:45:02',_binary ''),(16,20,165,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-05 11:14:06',NULL,_binary ''),(17,22,179,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-06 05:28:57',NULL,_binary ''),(18,23,163,'{\"awards\": [{\"awardTitle\": \"AWS\", \"awardedDate\": 1641168000000, \"description\": \"West\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-07 07:44:31',NULL,_binary ''),(19,24,164,'{\"awards\": [{\"awardTitle\": \"Best Services\", \"awardedDate\": 1639526400000, \"description\": \"Best Services\"}, {\"awardTitle\": \"Services\", \"awardedDate\": 1640995200000, \"description\": \"Services\"}, {\"awardTitle\": \"Renuwal\", \"awardedDate\": 1661990400000, \"description\": \"Se\"}]}','2022-09-07 10:28:09',NULL,_binary ''),(20,25,180,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-08 09:52:22','2022-09-08 10:02:27',_binary ''),(21,26,180,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-08 10:44:27','2023-04-20 08:18:29',_binary ''),(22,27,181,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-08 10:55:37','2022-09-08 11:00:54',_binary ''),(23,28,181,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-08 11:08:35',NULL,_binary ''),(24,29,163,'{\"awards\": [{\"awardTitle\": \"AWS\", \"awardedDate\": 1641168000000, \"description\": \"West\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-09-09 14:39:21','2022-10-28 10:31:01',_binary ''),(25,30,165,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2022-10-10 09:17:06','2022-10-10 09:17:45',_binary ''),(26,31,180,'{\"awards\": [{\"awardTitle\": \"latestq1\", \"awardedDate\": 1683072000000, \"description\": \"unique\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2023-05-05 07:19:34','2023-05-05 07:20:31',_binary ''),(27,36,204,'{\"awards\": [{\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}, {\"awardTitle\": \"\", \"awardedDate\": null, \"description\": \"\"}]}','2023-06-14 05:36:11','2023-06-14 05:36:47',_binary '');
/*!40000 ALTER TABLE `renewal_sp_business_other_details` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:32:58
