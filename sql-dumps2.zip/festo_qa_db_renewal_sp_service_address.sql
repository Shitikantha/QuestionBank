-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `renewal_sp_service_address`
--

DROP TABLE IF EXISTS `renewal_sp_service_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `renewal_sp_service_address` (
  `Renewal_Service_Address_Id` bigint NOT NULL AUTO_INCREMENT,
  `Renewal_Id` bigint NOT NULL,
  `Sp_Reg_Id` bigint NOT NULL,
  `Address_Line_1` varchar(200) DEFAULT NULL,
  `Address_Line_2` varchar(200) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `State` varchar(50) DEFAULT NULL,
  `Country` varchar(50) DEFAULT NULL,
  `Zip_Code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Renewal_Service_Address_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `renewal_sp_service_address`
--

LOCK TABLES `renewal_sp_service_address` WRITE;
/*!40000 ALTER TABLE `renewal_sp_service_address` DISABLE KEYS */;
INSERT INTO `renewal_sp_service_address` VALUES (201,11,167,'street1','street2','florida','Delvinë District','AL','500047'),(202,12,164,'482 West Green New Street','Provident vero temporibus lab','Lorem voluptate','Alaska','US','89190'),(203,13,164,'482 West Green New Street','Provident vero temporibus lab','Lorem voluptate','Alaska','US','89190'),(204,14,164,'Flot No:205','Ayyapa Society ','Hyderbad','Andhra Pradesh','IN','500018'),(205,15,164,'Flot No:205','Ayyapa Society ','Hyderbad','Andhra Pradesh','IN','500018'),(206,16,164,'Flot No:205','Ayyapa Society ','Hyderbad','Andhra Pradesh','IN','500018'),(207,17,164,'Flot No:205','Ayyapa Society ','Hyderbad','Andhra Pradesh','IN','500018'),(208,18,163,'48 East White Cowley','Tempora ','Voluptatum quis','Andhra Pradesh','IN','22681'),(209,19,169,'4-13','Veagur','Nellore','Andhra Pradesh','IN','524318'),(210,20,165,'test adress','test adress two','madurai','Tamil Nadu','IN','KLJKSJDAS'),(211,22,179,'2/348A Gayathiri nagar first s','treet, uchaparambu medu, iyer ','Madurai','Tamil Nadu','IN','625014'),(212,23,163,'48 East White Cowley','Tempora ','Voluptatum quis','Andhra Pradesh','IN','22681'),(213,24,164,'Flot No:205','Ayyapa Society ','Hyderbad','Andhra Pradesh','IN','500018'),(214,25,180,'Kareativari Veadhi','Opposite RTC Bus stand ','Nellore','Andhra Pradesh','IN','524318'),(215,26,180,'Kareativari Veadhi','Opposite RTC Bus stand ','Nellore','Andhra Pradesh','IN','AAAANNCNC3'),(216,27,181,'66B','Opposite Bhavani Medicals','Hyderbad','Andhra Pradesh','IN','500018'),(217,28,181,'66B','Opposite Bhavani Medicals','Hyderbad','Andhra Pradesh','IN','500018'),(218,29,163,'48 East White Cowley','Tempora ','Voluptatum quis','Andhra Pradesh','IN','22681'),(219,30,165,'test adress','test adress two','madurai','Tamil Nadu','IN','KLJKSJDAS'),(220,31,180,'Kareativari Veadhi','Opposite RTC Bus stand ','Nellore','Andhra Pradesh','IN','AAAANNCNC3'),(221,36,204,'39','1','kkdi','Tamil Nadu','IN','630001');
/*!40000 ALTER TABLE `renewal_sp_service_address` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:33:54
