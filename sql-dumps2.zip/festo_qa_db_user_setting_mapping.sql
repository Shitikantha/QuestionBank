-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user_setting_mapping`
--

DROP TABLE IF EXISTS `user_setting_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_setting_mapping` (
  `User_Setting_Mapping_Id` int NOT NULL AUTO_INCREMENT,
  `User_Name` varchar(75) NOT NULL,
  `Setting_Id` int NOT NULL,
  `Is_Enable` bit(1) DEFAULT NULL,
  `Created_Date` datetime DEFAULT NULL,
  `Updated_Date` datetime DEFAULT NULL,
  PRIMARY KEY (`User_Setting_Mapping_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_setting_mapping`
--

LOCK TABLES `user_setting_mapping` WRITE;
/*!40000 ALTER TABLE `user_setting_mapping` DISABLE KEYS */;
INSERT INTO `user_setting_mapping` VALUES (1,'Anankris325060',6,_binary '','2023-06-12 09:34:41','2023-06-12 09:34:41'),(2,'Anankris325060',7,_binary '\0','2023-06-12 09:34:46','2023-06-12 09:36:03'),(3,'Anankris325060',8,_binary '','2023-06-12 09:36:01','2023-06-12 09:36:01'),(4,'satyuat935436',8,_binary '','2023-06-12 11:16:40','2023-06-12 11:16:40'),(5,'satyuat269013',2,_binary '','2023-06-13 04:49:21','2023-06-13 04:49:21'),(6,'MuraKris249355',1,_binary '\0','2023-06-14 05:16:26','2023-06-15 11:38:46'),(7,'MuraKris249355',2,_binary '\0','2023-06-14 05:16:28','2023-06-15 11:38:48'),(8,'vignP395173',6,_binary '','2023-06-14 06:04:30','2023-06-14 06:04:30'),(9,'vignP395173',7,_binary '\0','2023-06-14 06:04:32','2023-06-14 06:06:16'),(10,'vignP395173',8,_binary '','2023-06-14 06:06:18','2023-06-14 06:06:18'),(11,'vignp170329',1,_binary '','2023-06-14 06:07:06','2023-06-14 06:07:06'),(12,'vignp170329',3,_binary '','2023-06-14 06:07:08','2023-06-14 06:07:08'),(13,'MuraKris249355',3,_binary '','2023-06-15 11:38:40','2023-06-15 11:38:40'),(14,'MuraKris249355',4,_binary '','2023-06-15 11:38:44','2023-06-15 11:38:44'),(15,'MallEven158674',6,_binary '','2023-06-15 11:40:21','2023-06-15 11:40:21'),(16,'MallEven158674',7,_binary '','2023-06-15 11:40:24','2023-06-15 11:40:24');
/*!40000 ALTER TABLE `user_setting_mapping` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:32:45
