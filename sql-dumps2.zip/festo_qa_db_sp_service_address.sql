-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `sp_service_address`
--

DROP TABLE IF EXISTS `sp_service_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sp_service_address` (
  `Service_Address_Id` bigint NOT NULL AUTO_INCREMENT,
  `Sp_Reg_Id` bigint DEFAULT NULL,
  `Address_Line_1` varchar(200) DEFAULT NULL,
  `Address_Line_2` varchar(200) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `State` varchar(50) DEFAULT NULL,
  `Country` varchar(50) DEFAULT NULL,
  `Zip_Code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Service_Address_Id`),
  KEY `Sp_Reg_Id` (`Sp_Reg_Id`),
  CONSTRAINT `sp_service_address_ibfk_1` FOREIGN KEY (`Sp_Reg_Id`) REFERENCES `sp_business_owner_info` (`SP_Reg_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sp_service_address`
--

LOCK TABLES `sp_service_address` WRITE;
/*!40000 ALTER TABLE `sp_service_address` DISABLE KEYS */;
INSERT INTO `sp_service_address` VALUES (155,162,'test','tambaram','Oyyava','Canillo','AD','211221'),(156,163,'48 East White Cowley','Tempora ','Voluptatum quis','Andhra Pradesh','IN','22681'),(157,164,'Flot No:205','Ayyapa Society ','Hyderbad','Andhra Pradesh','IN','500018'),(158,165,'test adress','test adress two','madurai','Tamil Nadu','IN','KLJKSJDAS'),(159,166,'66B','Opposite Bhavani Medicals ','Hyderbad','Andhra Pradesh','IN','524318'),(160,167,'street1','street2','florida','Delvinë District','AL','500047'),(161,168,'66 West Hague Lane','Non totam architecto veniam i','Et rerum eos qu','Bulqizë District','AL','72593'),(162,169,'4-13','Veagur','Nellore','Andhra Pradesh','IN','524318'),(163,170,'68 North Green Fabien','Sed aut corrupti fugiat quaer','Eum mollit aut ','Tamil Nadu','IN','37711'),(164,171,'Quarter number 3258, Sector 4G','Bokaro steel city','Bokaro ','Jharkhand','IN','827004'),(165,172,'Vidavalur','Parlapali','Hyderbad','Andhra Pradesh','IN','524008'),(166,173,'68 West Clarendon Freeway','Rerum aperiam minus quisquam i','Ipsam possimus','Aïn Témouchent','DZ','81126'),(167,174,'93 New Drive','Illum maiores magnam debitis ','Sed dolorem dol','Andhra Pradesh','IN','53957'),(168,175,'Saundatti','Bangalore','Bangalore','Karnataka','IN','560044'),(169,176,'Chemukula vari street','c-49/3','Nellore','Andhra Pradesh','IN','524318'),(170,177,'63 North Cowley Boulevard','Elit id est praesentium aut ','Voluptate dolor','Canillo','AD','43452'),(171,178,'179 Green Cowley Street','Adipisicing nemo possimus ex ','Dicta cupidatat','','','55643'),(172,179,'2/348A Gayathiri nagar first s','treet, uchaparambu medu, iyer ','Madurai','Tamil Nadu','IN','625014'),(173,180,'Kareativari Veadhi','Opposite RTC Bus stand ','Nellore','Andhra Pradesh','IN','AAAANNCNC3'),(174,181,'66B','Opposite Bhavani Medicals','Hyderbad','Andhra Pradesh','IN','500018'),(175,182,'','','','','',''),(176,183,'1-7-14/B','Subash Nagar','Nellore','Andhra Pradesh','IN','ASW4455666'),(177,184,'Kovur','Nellore','Nellore','Andhra Pradesh','IN','524001'),(180,186,'','','','','',''),(181,187,'','','','','',''),(182,188,'','','','','',''),(183,189,'aaa','aaa','kkfi','Tamil Nadu','IN','630001'),(184,190,'Address one','address two','madurai','Tamil Nadu','IN','625014'),(185,192,'','','','','',''),(186,193,'test','uiyuhiuy','madurai','Tamil Nadu','IN','625014'),(187,194,'Vidavalur','Nellore','Nellore','Andhra Pradesh','IN','524318'),(188,195,'66B','Opposite  to Bhavani Medicals','Hyderbad','Andhra Pradesh','IN','500068'),(189,196,'Library Street','NTR Center','Hyderbad','Andhra Pradesh','IN','524318'),(190,197,'Vidavalur Mandal','Parking','Hyderbad','Andhra Pradesh','IN','524318'),(191,198,'Sanatha Nagar','Near Bus stop','Hyderbad','Telangana','IN','524318'),(192,199,'Pune Building','','Pune','Maharashtra','IN','431136'),(193,200,'Address 1','Address 2','Hyderabad','Telangana','IN','500045'),(194,201,'Flot No:101','Opposite Sindhu Nivas ','Hyderbad','Telangana','IN','500018'),(195,202,'jagamara, bbsr, odisha','','Bbsr','Odisha','IN','756025'),(196,203,'001','Abcd','Bangalore ','Karnataka','IN','560067'),(197,204,'39','1','kkdi','Tamil Nadu','IN','630001');
/*!40000 ALTER TABLE `sp_service_address` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:31:23
