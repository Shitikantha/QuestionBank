-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: festo-qa1-db-ctr-cluster01.cluster-ccblohpuc6ou.us-east-1.rds.amazonaws.com    Database: festo_qa_db
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user_role_mapping`
--

DROP TABLE IF EXISTS `user_role_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role_mapping` (
  `User_Role_Mapping_Id` int NOT NULL AUTO_INCREMENT,
  `User_Name` varchar(75) DEFAULT NULL,
  `Role_Id` int DEFAULT NULL,
  PRIMARY KEY (`User_Role_Mapping_Id`),
  KEY `User_Id_FK_idx` (`User_Name`),
  KEY `Role_ID_FK_idx` (`Role_Id`),
  CONSTRAINT `Role_ID_FK` FOREIGN KEY (`Role_Id`) REFERENCES `user_roles` (`Role_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role_mapping`
--

LOCK TABLES `user_role_mapping` WRITE;
/*!40000 ALTER TABLE `user_role_mapping` DISABLE KEYS */;
INSERT INTO `user_role_mapping` VALUES (16,'BidyBara442611',3),(17,'Rohieven715836',2),(18,'KumaBand909952',2),(19,'vandChou777569',1),(20,'BandKuma680440',3),(21,'MallEven158674',2),(22,'MallServ386183',1),(24,'PrudAdmi100098',1),(25,'VijaServ869995',2),(26,'VeenS731511',2),(27,'MallAdmi731421',3),(28,'HarsServ540941',1),(29,'RajiCust502269',2),(31,'threbpm232264',1),(32,'onebbpm780363',2),(33,'mohabpml144550',3),(34,'testEmp999957',2),(35,'ServServ322717',1),(36,'Rakeserv186196',1),(37,'RakeEven983293',2),(38,'RakeAdmi292275',3),(39,'VijaMR571644',2),(40,'VijaMR796715',2),(41,'AnanKris379023',1),(42,'VeenS919915',2),(43,'RajeG925250',1),(44,'MohaAzma588006',3),(45,'fivebpm725195',1),(46,'twobpm822659',2),(47,'MallT470339',1),(48,'VignArmu834883',1),(49,'NaveB342900',2),(50,'ServProv131077',1),(51,'ShanT138611',1),(52,'anankris312370',1),(53,'shanP216794',2),(54,'hariP208511',1),(55,'AnanServ512301',1),(56,'MuraKris249355',1),(57,'ZaheSH858872',1),(58,'Zaheone296189',2),(59,'Rajeg934445',2),(60,'zackspar476393',2),(61,'Rajegg536262',2),(62,'AbcDef170503',2),(63,'HarsCh620487',2),(64,'Swaksw815641',2),(65,'Bidyb197582',2),(66,'BidyBara217511',2),(67,'eighprov887531',1),(68,'Swass239210',1),(69,'SownKuma514926',1),(70,'ShanT709190',1),(71,'vamsk164530',1),(72,'testtest836979',2),(73,'Parnch169288',2),(74,'Mallt778176',2),(75,'Anankris325060',2),(76,'Anils943478',1),(77,'Manvt676071',2),(78,'vignpala178433',2),(79,'jayachan347218',1),(80,'elevprov650321',1),(81,'CherV646071',1),(82,'twelprov524016',1),(83,'thirrpvo312645',1),(84,'jaichan268437',2),(85,'rajit309462',1),(86,'susmith994694',1),(87,'SMFVend820074',1),(88,'smfcust741618',2),(89,'vendTwo996457',1),(90,'SMFVend747410',1),(91,'SaiT492302',1),(92,'BalaJio512679',1),(93,'Balajio176722',1),(94,'SMFvend461938',1),(95,'SwapDhot773235',1),(96,'danvh906232',1),(97,'jayachan462217',3),(98,'vignpala709767',1),(99,'DiptMudu326114',3),(100,'DiptMudu630185',1),(101,'DiptBPM510788',2),(102,'jayav417761',2),(103,'AnanKris620937',2),(104,'ChenYell496198',2),(105,'EvenTest553767',2),(106,'satyuat935436',2),(107,'satyuat269013',1),(108,'vignp170329',1),(109,'vignP395173',2);
/*!40000 ALTER TABLE `user_role_mapping` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-30  3:33:15
